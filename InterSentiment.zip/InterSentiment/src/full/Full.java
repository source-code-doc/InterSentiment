package full;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import model.DocAverage;
import model.MLP;
import model.NeuralCF;
import nnet.AverageLayer;
import nnet.LookupLayer;
import nnet.LookupLinearTanh;
import nnet.MultiConnectLayer;
import other.Data;
import other.Funcs;
import other.Metric;

public class Full {
	LookupLinearTanh xseedLLT1;
	LookupLinearTanh xseedLLT2;
	LookupLinearTanh xseedLLT3;
	MultiConnectLayer connect;
	AverageLayer average;
	
	LookupLayer userLookup;
	LookupLayer itemLookup;
	MultiConnectLayer connectUserItem;
	MLP mlpUserItem;
	
	HashMap<String, Integer> wordVocab;
	HashMap<String, Integer> userVocab;
	HashMap<String, Integer> itemVocab;
	NeuralCF neuralCF;
	int classNum;
	String inputDir;
	String unkStr = "<unk>";
	
	public Full(
				String embeddingWordFile,
				int embeddingWordLength,
				int outputLengthWordLookup,
				int embeddingLenUserLookup,
				int embeddingLenItemLookup,
				int xClassNum,
				int xMLPL,
				int xMLPX,
				String xInputDir,
				String trainFile,
				String testFile
				) throws Exception{
		classNum = xClassNum;
		inputDir = xInputDir;
		loadData(trainFile, testFile);
		int embeddingLineCount = Funcs.lineCounter(embeddingWordFile, "utf8");
		double[][] table = new double[embeddingLineCount][];
		wordVocab = new HashMap<String, Integer>();
		Funcs.loadEmbeddingFile(embeddingWordFile, embeddingWordLength, "utf8", false, wordVocab, table);
		//
		xseedLLT1 = new LookupLinearTanh(1, wordVocab.size(), outputLengthWordLookup, embeddingWordLength);
		xseedLLT1.lookup.setEmbeddings(table);		
		xseedLLT2 = new LookupLinearTanh(2, wordVocab.size(), outputLengthWordLookup, embeddingWordLength);
		xseedLLT2.lookup.setEmbeddings(table);
		xseedLLT3 = new LookupLinearTanh(3, wordVocab.size(), outputLengthWordLookup, embeddingWordLength);
		xseedLLT3.lookup.setEmbeddings(table);
		//
		connect = new MultiConnectLayer(
				new int[]{outputLengthWordLookup, outputLengthWordLookup, outputLengthWordLookup});
		//
		average = new AverageLayer(connect.outputLength, outputLengthWordLookup);
		connect.link(average);
		
		// user item lookup layers
		userLookup = new LookupLayer(embeddingLenUserLookup, userVocab.size(), 1);
		itemLookup = new LookupLayer(embeddingLenItemLookup, itemVocab.size(), 1);
		
		connectUserItem = new MultiConnectLayer(new int[]{embeddingLenUserLookup, embeddingLenItemLookup});
		userLookup.link(connectUserItem, 0);
		itemLookup.link(connectUserItem, 1);	
		//
		mlpUserItem = new MLP(connectUserItem.outputLength, outputLengthWordLookup,xMLPL);
		connectUserItem.link(mlpUserItem);
		neuralCF = new NeuralCF(new int[]{outputLengthWordLookup, outputLengthWordLookup}, xMLPX);
		mlpUserItem.link(neuralCF,0);
		average.link(neuralCF,1);
		
		Random rnd = new Random(); 
		xseedLLT1.XavierInitialization(rnd);
		xseedLLT2.XavierInitialization(rnd);
		xseedLLT3.XavierInitialization(rnd);
		userLookup.XavierInitialization(rnd);
		itemLookup.XavierInitialization(rnd);
		mlpUserItem.XavierInitialization(rnd);
		neuralCF.XavierInitialization(rnd);
	}
	
	List<Data> trainDataList;
	List<Data> testDataList;  
	//
	public void loadData(String trainFile, String testFile)
	{
		System.out.println("================ start loading corpus ==============");
		trainDataList = new ArrayList<Data>();  
		userVocab = new HashMap<String, Integer>();
		itemVocab = new HashMap<String, Integer>();
		Funcs.loadCorpus(trainFile, "utf8", trainDataList);
		for(Data data: trainDataList)
		{
			if(!userVocab.containsKey(data.userStr))
			{
				userVocab.put(data.userStr, userVocab.size());
			}
			if(!itemVocab.containsKey(data.productStr))
			{
				itemVocab.put(data.productStr, itemVocab.size());
			}
		}
		testDataList = new ArrayList<Data>();  
		Funcs.loadCorpus(testFile, "utf8", testDataList);
		System.out.println("================ finsh loading corpus ==============");
	}
	
	public void run(int roundNum, double learningRate, double lambda, double regularizationFreq) throws Exception
	{
		double lossV = 0.0;
		int lossC = 0;
		for(int round = 1; round <= roundNum; round++)
		{
			System.out.println("============== running round: " + round + " ===============");
			Collections.shuffle(trainDataList, new Random());

			for(int idxData = 0; idxData < trainDataList.size(); idxData++)
			{
				Data data = trainDataList.get(idxData);
				String[] sentences = data.reviewText.split("<sssss>");
				
				int[][] wordIdMatrix = Funcs.fillDocument(sentences, wordVocab, unkStr);
				
				DocAverage docAverage1 = new DocAverage(
						xseedLLT1,
						wordIdMatrix, 
						wordVocab.get(unkStr));
				
				DocAverage docAverage2 = new DocAverage(
						xseedLLT2,
						wordIdMatrix, 
						wordVocab.get(unkStr));
				
				DocAverage docAverage3 = new DocAverage(
						xseedLLT3,
						wordIdMatrix, 
						wordVocab.get(unkStr));
				
				if(docAverage1.sentenceConvList.size() == 0
					|| docAverage2.sentenceConvList.size() == 0
					|| docAverage3.sentenceConvList.size() == 0)
				{
					System.out.println(data.toString() + "docAverage.sentenceConvList.size() == 0");
					continue;
				}
				
				userLookup.input[0] = userVocab.get(data.userStr);
				itemLookup.input[0] = itemVocab.get(data.productStr);
				
				// important
				docAverage1.link(connect, 0);
				docAverage2.link(connect, 1);
				docAverage3.link(connect, 2);
				
				// forward
 				docAverage1.forward();
 				docAverage2.forward();
 				docAverage3.forward();
 				connect.forward();
				average.forward();

				userLookup.forward();
				itemLookup.forward();
				connectUserItem.forward();
				mlpUserItem.forward();
 				
 				neuralCF.forward();
				
				// set squared-loss
				int goldRating = data.goldRating;
				double predRating =  Funcs.squash(neuralCF.output[0], 1, classNum);
				lossV += Math.pow(goldRating - predRating, 2);
				lossC += 1;
				if(goldRating == neuralCF.output[0])
					continue;
				double phi_derivative = (predRating-1.0)*(classNum-predRating)/(classNum-1.0);
				neuralCF.outputG[0] = (goldRating - predRating) * phi_derivative;
				
				// backward
				neuralCF.backward();
				mlpUserItem.backward();
				connectUserItem.backward();
				userLookup.backward();
				itemLookup.backward();
				average.backward();
				connect.backward();
				docAverage1.backward();
				docAverage2.backward();
				docAverage3.backward();
				
				// update
				neuralCF.update(learningRate);
				mlpUserItem.update(learningRate);
				docAverage1.update(learningRate);
				docAverage2.update(learningRate);
				docAverage3.update(learningRate);
				userLookup.update(learningRate);
				itemLookup.update(learningRate);
				
				// regularization
				if(lossC % regularizationFreq == 0)
				{
					neuralCF.regularizationNeuralCF(lambda);
					mlpUserItem.regularizationMLP(lambda);
					xseedLLT1.regularizationLinear(lambda);
					xseedLLT2.regularizationLinear(lambda);
					xseedLLT3.regularizationLinear(lambda);
					xseedLLT2.lookup.regularizationLookup(lambda);
					userLookup.regularizationLookup(lambda);
					itemLookup.regularizationLookup(lambda);
				}
				
				// clearGrad
				docAverage1.clearGrad();
				docAverage2.clearGrad();
				docAverage3.clearGrad();
				connect.clearGrad();
				average.clearGrad();
				userLookup.clearGrad();
				itemLookup.clearGrad();
				connectUserItem.clearGrad();
				mlpUserItem.clearGrad();
				neuralCF.clearGrad();
				
				if(idxData % 3000 == 0)
				{
					System.out.println("running idxData = " + idxData + "/" + trainDataList.size() + "\t "
							+ "lossV/lossC = " + lossV + "/" + lossC + "\t"
							+ " = " + lossV/lossC
							+ "\t" + new Date().toLocaleString());
				}
			}
			learningRate *= 0.9;
			System.out.println("============= finish training round: " + round + " ==============");
			predict(round);
		}
	}
	
	public void predict(int round) throws Exception
	{
		System.out.println("=========== predicting round: " + round + " ===============");
		
		List<Integer> goldList = new ArrayList<Integer>();
		List<Double> predList = new ArrayList<Double>();
		List<String> tagList = new ArrayList<String>();
		
		for(int idxData = 0; idxData < testDataList.size(); idxData++)
		{
			Data data = testDataList.get(idxData);
			String[] sentences = data.reviewText.split("<sssss>");
			int[][] wordIdMatrix = Funcs.fillDocument(sentences, wordVocab, unkStr);
			
			DocAverage docAverage1 = new DocAverage(
					xseedLLT1,
					wordIdMatrix, 
					wordVocab.get(unkStr));
			
			DocAverage docAverage2 = new DocAverage(
					xseedLLT2,
					wordIdMatrix, 
					wordVocab.get(unkStr));
			
			DocAverage docAverage3 = new DocAverage(
					xseedLLT3,
					wordIdMatrix, 
					wordVocab.get(unkStr));
			
			if(docAverage1.sentenceConvList.size() == 0  
				|| docAverage2.sentenceConvList.size() == 0
				|| docAverage3.sentenceConvList.size() == 0)
			{
				System.out.println(data.toString() + "docAverage.sentenceConvList.size() == 0");
				continue;
			}
			
			userLookup.input[0] = userVocab.get(data.userStr);
			itemLookup.input[0] = itemVocab.get(data.productStr);
			
			// important
			docAverage1.link(connect, 0);
			docAverage2.link(connect, 1);
			docAverage3.link(connect, 2);
			
			// forward
			docAverage1.forward();
			docAverage2.forward();
			docAverage3.forward();
			connect.forward();
			average.forward();

			userLookup.forward();
			itemLookup.forward();
			connectUserItem.forward();
			mlpUserItem.forward();
			neuralCF.forward();
			
			double predRating =  Funcs.squash(neuralCF.output[0], 1, classNum);
			
			predList.add(predRating);
			goldList.add(data.goldRating);
			tagList.add(data.userStr+" "+data.productStr);
		}
		
		Metric.calcMetric(goldList, predList);
		Funcs.dumpTestResult(inputDir+"/pred"+round+".txt", goldList, predList, tagList, "utf-8");
		System.out.println("============== finish predicting =================");
	}
	
	public static void main(String[] args) throws Exception
	{
		int embeddingWordLength = 200;
		int outputLenWordLookup = 16;
		int classNum = 5;
		int embeddingLenUserLookup = 200;
		int embeddingLenItemLookup = 200;
		String inputDir = "yelp14";
		int roundNum = 10;
		double learningRate = 0.05;
		double lambda = 0.001;
		double regularizationFreq = 20000;
		int mlpL = 3;
		int mlpX = 1;
		String embeddingWordFile = inputDir+"/"+inputDir+"-words.txt";
		String trainFile = inputDir+"/"+inputDir+".train.txt";
		String testFile = inputDir+"/"+inputDir+".test.txt";
		
		Full main = new Full(
				embeddingWordFile,
				embeddingWordLength,
				outputLenWordLookup,
				embeddingLenUserLookup,
				embeddingLenItemLookup,
				classNum,
				mlpL,
				mlpX,
				inputDir,
				trainFile, 
				testFile);
		
		main.run(roundNum,
				learningRate,
				lambda,
				regularizationFreq);
	}
}
