package full;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import model.MLP;
import nnet.LookupLayer;
import nnet.MultiConnectLayer;
import nnet.OutputWeightLayer;
import other.Data;
import other.Funcs;
import other.Metric;

public class Full_delR {
	LookupLayer userLookup;
	LookupLayer itemLookup;
	MultiConnectLayer connectUserItem;
	MLP mlpUserItem;
	OutputWeightLayer outputWeight;
	
	HashMap<String, Integer> userVocab;
	HashMap<String, Integer> itemVocab;
	int classNum;
	String inputDir;
	String unkStr = "<unk>";
	
	public Full_delR(
				int outputLengthWordLookup,
				int embeddingLenUserLookup,
				int embeddingLenItemLookup,
				int xClassNum,
				int xMLPL,
				String xInputDir,
				String trainFile,
				String testFile
				) throws Exception
	{
		classNum = xClassNum;
		inputDir = xInputDir;
		loadData(trainFile, testFile);
		// user item lookup layers
		userLookup = new LookupLayer(embeddingLenUserLookup, userVocab.size(), 1);
		itemLookup = new LookupLayer(embeddingLenItemLookup, itemVocab.size(), 1);
		
		connectUserItem = new MultiConnectLayer(new int[]{embeddingLenUserLookup, embeddingLenItemLookup});
		userLookup.link(connectUserItem, 0);
		itemLookup.link(connectUserItem, 1);	
		//
		mlpUserItem = new MLP(connectUserItem.outputLength, outputLengthWordLookup, xMLPL);
		connectUserItem.link(mlpUserItem);
		
		outputWeight = new OutputWeightLayer(mlpUserItem.OutputLength,1);
		mlpUserItem.link(outputWeight);
		
		Random rnd = new Random(); 
		userLookup.XavierInitialization(rnd);
		itemLookup.XavierInitialization(rnd);
		mlpUserItem.XavierInitialization(rnd);
		outputWeight.XavierInitialization(rnd);
	}
	
	List<Data> trainDataList;
	List<Data> testDataList;  
	//
	public void loadData(String trainFile, String testFile)
	{
		System.out.println("================ start loading corpus ==============");
		trainDataList = new ArrayList<Data>();  
		userVocab = new HashMap<String, Integer>();
		itemVocab = new HashMap<String, Integer>();
		Funcs.loadCorpus(trainFile, "utf8", trainDataList);
		for(Data data: trainDataList)
		{
			if(!userVocab.containsKey(data.userStr))
			{
				userVocab.put(data.userStr, userVocab.size());
			}
			if(!itemVocab.containsKey(data.productStr))
			{
				itemVocab.put(data.productStr, itemVocab.size());
			}
		}
		testDataList = new ArrayList<Data>();  
		Funcs.loadCorpus(testFile, "utf8", testDataList);
		System.out.println("================ finsh loading corpus ==============");
	}
	
	public void run(int roundNum, double learningRate, double lambda, double regularizationFreq) throws Exception
	{
		double lossV = 0.0;
		int lossC = 0;
		for(int round = 1; round <= roundNum; round++)
		{
			System.out.println("============== running round: " + round + " ===============");
			Collections.shuffle(trainDataList, new Random());

			for(int idxData = 0; idxData < trainDataList.size(); idxData++)
			{
				Data data = trainDataList.get(idxData);
				userLookup.input[0] = userVocab.get(data.userStr);
				itemLookup.input[0] = itemVocab.get(data.productStr);
				// forward
				userLookup.forward();
				itemLookup.forward();
				connectUserItem.forward();
				mlpUserItem.forward();
				outputWeight.forward();
				
				// set squared-loss
				int goldRating = data.goldRating;
				double predRating =  Funcs.squash(outputWeight.output[0], 1, classNum);
				lossV += Math.pow(goldRating - predRating, 2);
				lossC += 1;
				if(goldRating == outputWeight.output[0])
					continue;
				double phi_derivative = (predRating-1.0)*(classNum-predRating)/(classNum-1.0);
				outputWeight.outputG[0] = (goldRating - predRating)* phi_derivative;
				// backward
				outputWeight.backward();
				mlpUserItem.backward();
				connectUserItem.backward();
				userLookup.backward();
				itemLookup.backward();
				
				// update
				outputWeight.update(learningRate);
				mlpUserItem.update(learningRate);
				userLookup.update(learningRate);
				itemLookup.update(learningRate);
				
				// regularization
				if(lossC % regularizationFreq == 0)
				{
					outputWeight.regularizationLinear(lambda);
					mlpUserItem.regularizationMLP(lambda);
					userLookup.regularizationLookup(lambda);
					itemLookup.regularizationLookup(lambda);
				}
				
				// clearGrad
				userLookup.clearGrad();
				itemLookup.clearGrad();
				connectUserItem.clearGrad();
				mlpUserItem.clearGrad();
				outputWeight.clearGrad();
				if(idxData % 10000 == 0)
				{
					System.out.println("running idxData = " + idxData + "/" + trainDataList.size() + "\t "
							+ "lossV/lossC = " + lossV + "/" + lossC + "\t"
							+ " = " + lossV/lossC);
				}
			}
			learningRate *= 0.9;
			System.out.println("============= finish training round: " + round + " ==============");
			predict(round);
		}
	}
	
	public void predict(int round) throws Exception
	{
		System.out.println("=========== predicting round: " + round + " ===============");
		
		List<Integer> goldList = new ArrayList<Integer>();
		List<Double> predList = new ArrayList<Double>();
		List<String> tagList = new ArrayList<String>();
		
		for(int idxData = 0; idxData < testDataList.size(); idxData++)
		{
			Data data = testDataList.get(idxData);
			userLookup.input[0] = userVocab.get(data.userStr);
			itemLookup.input[0] = itemVocab.get(data.productStr);

			userLookup.forward();
			itemLookup.forward();
			connectUserItem.forward();
			mlpUserItem.forward();
			outputWeight.forward();
			
			double predRating =  Funcs.squash(outputWeight.output[0], 1, classNum);
			
			predList.add(predRating);
			goldList.add(data.goldRating);
			tagList.add(data.userStr+" "+data.productStr);
		}
		
		Metric.calcMetric(goldList, predList);
		Funcs.dumpTestResult(inputDir+"/pred"+round+".txt", goldList, predList, tagList, "utf-8");
		System.out.println("============== finish predicting =================");
	}
	
	public static void main(String[] args) throws Exception
	{
		int outputLenWordLookup = 16;
		int classNum = 5;
		int embeddingLenUserLookup = 200;
		int embeddingLenItemLookup = 200;
		String inputDir = "yelp14";
		int roundNum = 30;
		double learningRate = 0.05;
		double lambda = 0.001;
		double regularizationFreq = 20000;
		int mlpL = 3;
		String trainFile = inputDir+"/"+inputDir+".train.txt";
		String testFile = inputDir+"/"+inputDir+".test.txt";
		
		Full_delR main = new Full_delR(
				outputLenWordLookup,
				embeddingLenUserLookup,
				embeddingLenItemLookup,
				classNum, 
				mlpL,
				inputDir,
				trainFile, 
				testFile);
		
		main.run(roundNum,
				learningRate,
				lambda,
				regularizationFreq);
	}
}
