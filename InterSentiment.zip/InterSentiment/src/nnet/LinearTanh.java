package nnet;

import java.util.Random;

public class LinearTanh implements NNInterface{
	public int InputLength;
	public int OutputLength;
	public LinearLayer linear;
	public TanhLayer tanh;
	int linkId;

	public LinearTanh() {

	}
	
	public LinearTanh(
			int xInputLength,
			int xOutputLength) throws Exception{
		InputLength = xInputLength;
		OutputLength = xOutputLength;
		linear = new LinearLayer(InputLength, OutputLength);
		tanh = new TanhLayer(OutputLength);
		linear.link(tanh);
		linkId = 0;
	}
	
	@Override
	public void randomize(Random r, double min, double max) {
		linear.randomize(r, min, max);
	}
	
	 public void XavierInitialization(Random r){
		 linear.XavierInitialization(r);
	 }

	@Override
	public void forward() {
		linear.forward();
		tanh.forward();
	}

	@Override
	public void backward() {
		tanh.backward();
		linear.backward();
	}

	@Override
	public void update(double learningRate) {
		linear.update(learningRate);
	}
	
	public void update(double learningRate, double lamda) {
		linear.update(learningRate, lamda);
	}

	@Override
	public void updateAdaGrad(double learningRate, int batchsize) {
	}

	@Override
	public void clearGrad() {
		linear.clearGrad();
		tanh.clearGrad();
	}

	@Override
	public void link(NNInterface nextLayer, int id) throws Exception {
		Object nextInputG = nextLayer.getInputG(id);
		Object nextInput = nextLayer.getInput(id);
		
		double[] nextI = (double[])nextInput;
		double[] nextIG = (double[])nextInputG; 
		
		if(nextI.length != tanh.length || nextIG.length != tanh.length)
		{
			throw new Exception("The Lengths of linked layers do not match.");
		}
		tanh.output = nextI;
		tanh.outputG = nextIG;
	}

	@Override
	public void link(NNInterface nextLayer) throws Exception {
		link(nextLayer, linkId);
	}

	@Override
	public Object getInput(int id) {
		return linear.input;
	}

	@Override
	public Object getOutput(int id) {
		return tanh.output;
	}

	@Override
	public Object getInputG(int id) {
		return linear.inputG;
	}

	@Override
	public Object getOutputG(int id) {
		return tanh.outputG;
	}

	@Override
	public Object cloneWithTiedParams() {
		return null;
	}
	
	public void regularizationLinear(double lambda) {
		linear.regularizationLinear(lambda);
	}

}
