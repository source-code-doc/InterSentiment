package other;

import java.util.List;

public class Metric {

	public static void calcMetric(List<Integer> goldLabelList, List<Double> predictLabelList)
	{
		if(goldLabelList.size() != predictLabelList.size())
		{
			System.err.println("gold length and predict length don't match!");
		}
		// mae = 1/N * (|gold_i - predict_i|)
		// rmse = sqrt(1/N * (gold_i - predict_i) * (gold_i - predict_i))
		double rmseDistance = 0;
//		double maeDistance = 0;
		for(int i = 0; i < goldLabelList.size(); i++)
		{
			int goldLabel = goldLabelList.get(i);
			double predictLabel = predictLabelList.get(i);
//			maeDistance += Math.abs(goldLabel - predictLabel);
			rmseDistance += Math.pow((goldLabel - predictLabel),2);
		}		
//		double mae = 1.0 * maeDistance / goldLabelList.size();
		double rmse = 1.0 * Math.sqrt(rmseDistance / goldLabelList.size());
		
//		System.out.println("MAE: " + mae);
		System.out.println("RMSE: " + rmse);
	}
}
class ClassCount{
	
	int gold = 0;
	int predict = 0;
	int match = 0;
	
	double p;
	double r;
	double f;
	
	public void update()
	{
		if(this.predict == 0)
		{
			p = 0.0;
		}
		else
		{
			p = 1.0 * this.match / this.predict;
		}
		
		r = 1.0 * this.match / this.gold;
		
		if(p < 0.000001 || r < 0.000001)
		{
			f = 0.0;
		}
		else
		{
			f = 2 * (p * r)/(p + r);
		}
	}
	
	public String toString()
	{
		String prf = "P: " + p + "\tR: " + r + "\tF: " + f;
		return prf;
	}
}